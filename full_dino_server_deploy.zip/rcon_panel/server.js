const express = require('express');
const bodyParser = require('body-parser');
const basicAuth = require('express-basic-auth');
const Rcon = require('rcon-client').Rcon;
const app = express();
app.use(bodyParser.json());
app.use(basicAuth({users: { [process.env.RCON_USER||'admin']: process.env.RCON_PANEL_PASS||'changeme' }, challenge: true}));
const RCON_HOST = process.env.RCON_HOST || '127.0.0.1';
const RCON_PORT = parseInt(process.env.RCON_PORT || '25575');
const RCON_PASS = process.env.RCON_PASS || 'changeme';
app.post('/api/command', async (req, res) => {
  if(!req.body || !req.body.command) return res.status(400).send('missing command');
  try {
    const rcon = await Rcon.connect({host:RCON_HOST, port:RCON_PORT, password:RCON_PASS});
    const resp = await rcon.send(req.body.command);
    await rcon.end();
    res.send(resp || 'OK');
  } catch (e) {
    res.status(500).send('RCON error: '+e.message);
  }
});
app.use('/', express.static(__dirname));
app.listen(3000, ()=>console.log('RCON panel running on :3000'));
