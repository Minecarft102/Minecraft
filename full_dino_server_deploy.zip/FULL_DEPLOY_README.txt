FULL DEPLOY GUIDE - Build, install, and run the Dino & Horse mod server
======================================================================

OVERVIEW
- This bundle contains everything you need to build the mod (using Forge MDK for 1.21.10), prepare a Linux VPS, run the Minecraft server, and host a secure RCON web panel.

STEP A - BUILD THE MOD (on your machine)
1. Download Forge MDK for Minecraft 1.21.10 (loader 60.x) from https://files.minecraftforge.net and extract it.
2. Copy the 'mod_source/src' and 'mod_source/resources' folders into the MDK's 'src/main/' (merge, do not overwrite your MDK files).
3. Edit MDK build.gradle if needed (the mod uses Java 17). Run: ./gradlew build
4. After a successful build, pick up the generated JAR from build/libs/ (e.g., dinohorse-1.0.0.jar).

STEP B - PREPARE SERVER (VPS recommended)
1. Upload the contents of 'server_pack' to /opt/minecraft/dino_server (or your preferred path).
2. Place the forge server jar (run the Forge installer in that folder to generate it) and the mod JAR into /opt/minecraft/dino_server/mods.
3. Create eula.txt with eula=true
4. Edit server.properties:
   - server-port=25565
   - enable-rcon=true
   - rcon.password=YOUR_STRONG_PASSWORD
   - rcon.port=25575
5. Create a 'minecraft' system user and chown the server folder to it.
6. Start the server: sudo -u minecraft ./start-server.sh
7. (Optional) Create a systemd service using the provided minecraft.service file and enable it: sudo systemctl enable --now minecraft

STEP C - DEPLOY RCON PANEL (secure)
1. Install Node.js (LTS): apt install nodejs npm
2. Copy rcon_panel/ to the VPS (outside the minecraft folder is OK).
3. Set env vars before starting the panel:
   export RCON_HOST=127.0.0.1
   export RCON_PORT=25575
   export RCON_PASS='the_rcon_password_from_server_properties'
   export RCON_USER='admin'
   export RCON_PANEL_PASS='your_panel_password'
4. Run: npm install && node server.js
5. Configure nginx to proxy https://your.domain/ to http://127.0.0.1:3000 using the provided nginx config as a starting point.
6. Use certbot to obtain SSL certs: sudo certbot --nginx -d your.domain

SECURITY NOTES
- Do NOT expose the RCON port to the public internet. Use nginx proxy + HTTPS and basic auth for the panel.
- Use a strong RCON password and rotate it if compromised.

MULTIMC / PLAYER INSTRUCTIONS
- Players can import the provided MultiMC manifest and drop the built mod JAR into the instance's mods/ folder.
- Connect to the public IP of your server once it's online.

SUPPORT
If you'd like, I can:
- Attempt to compile the mod for you if you upload the Forge MDK zip here.
- Customize spawn rates, add proper models/textures, and package a MultiMC zip with assets.
- Walk you step-by-step through any VPS provider (I can generate copy-paste commands).
