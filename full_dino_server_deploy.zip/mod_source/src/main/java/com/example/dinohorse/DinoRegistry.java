package com.example.dinohorse;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public class DinoRegistry {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DinoHorseMod.MODID);

    public static final RegistryObject<EntityType<?>> DINOSAUR = ENTITIES.register("dinosaur",
            () -> EntityType.Builder.of(DinosaurEntity::new, MobCategory.CREATURE).sized(1.2f, 1.6f).build("dinohorse:dinosaur"));

    public static final RegistryObject<EntityType<?>> CUSTOM_HORSE = ENTITIES.register("custom_horse",
            () -> EntityType.Builder.of(CustomHorseEntity::new, MobCategory.CREATURE).sized(0.9f, 1.6f).build("dinohorse:custom_horse"));
}
