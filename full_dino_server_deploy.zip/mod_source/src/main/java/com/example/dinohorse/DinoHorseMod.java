package com.example.dinohorse;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.GameType;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.eventbus.api.EventPriority;

// Main mod class
@Mod(DinoHorseMod.MODID)
public class DinoHorseMod {
    public static final String MODID = "dinohorse";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final RegistryObject<Item> SADDLE_ITEM = ITEMS.register("saddle_custom", () -> new Item(new Item.Properties().stacksTo(1)));

    public DinoHorseMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
    }

    // Set creative on join
    @EventBusSubscriber
    public static class PlayerHandler {
        @SubscribeEvent
        public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
            if (event.getPlayer() instanceof ServerPlayer) {
                ServerPlayer player = (ServerPlayer) event.getPlayer();
                try {
                    player.setGameMode(GameType.CREATIVE);
                } catch (Throwable t) {
                    player.getAbilities().mayBuild = true;
                    player.onUpdateAbilities();
                }
            }
        }
    }

    // Ensure natural drops - example extra drop for dinosaurs
    @EventBusSubscriber
    public static class DropsHandler {
        @SubscribeEvent(priority = EventPriority.NORMAL)
        public static void onLivingDrops(LivingDropsEvent event) {
            Level level = event.getEntity().level;
            if (level.isClientSide) return;
            ItemStack drop = new ItemStack(Items.BEEF, 1);
            ItemEntity ie = new ItemEntity(level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), drop);
            ie.setPickUpDelay(0);
            level.addFreshEntity(ie);
        }
    }
}
