package com.example.dinohorse;

import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;

public class CustomHorseEntity extends AbstractHorse {
    public CustomHorseEntity(EntityType<? extends AbstractHorse> type, Level level) {
        super(type, level);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && stack.getItem() == DinoHorseMod.SADDLE_ITEM.get()) {
            if (!this.isVehicle() && !player.isPassenger()) {
                player.startRiding(this);
                if (!player.isCreative()) stack.shrink(1);
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return super.mobInteract(player, hand);
    }
}
