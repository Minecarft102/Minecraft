#!/usr/bin/env bash
cd "$(dirname "$0")"
JAVA_CMD=${JAVA_CMD:-$(which java)}
if [ -z "$JAVA_CMD" ]; then echo "Java not found"; exit 1; fi
XMS=2G; XMX=8G
$JAVA_CMD -Xms${XMS} -Xmx${XMX} -jar forge-*.jar nogui
