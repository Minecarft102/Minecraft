#!/usr/bin/env bash
set -e
useradd -m -r -s /bin/bash minecraft || true
mkdir -p /opt/minecraft/dino_server
chown minecraft:minecraft /opt/minecraft/dino_server
apt update
apt install -y openjdk-17-jre-headless nginx certbot nodejs npm git unzip ufw
ufw allow 25565/tcp
ufw allow 80/tcp
ufw allow 3000/tcp
ufw --force enable
echo "VPS prepared. Upload server files to /opt/minecraft/dino_server and set up nginx site."
